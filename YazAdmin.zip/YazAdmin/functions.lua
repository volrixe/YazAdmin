TGSE = TriggerServerEvent
noclip = false 
NoClipSpeed = 2.0 
function KeyboardInput(entryTitle, textEntry, inputText, maxLength)
	AddTextEntry(entryTitle, textEntry)
	DisplayOnscreenKeyboard(1, entryTitle, '', inputText, '', '', '', maxLength)

	while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
		Citizen.Wait(0)
	end

	if UpdateOnscreenKeyboard() ~= 2 then
		local result = GetOnscreenKeyboardResult()
		Citizen.Wait(500)
		return result
	else
		Citizen.Wait(500)
		return nil
	end
end

function getItems()
    TGSE("Yazhu:getItems")
end

function RegisterCommandKey(action, description, defaultKey, callback)
    RegisterKeyMapping(action, description, 'keyboard', defaultKey)
    RegisterCommand(action, function()
        callback()
    end, false)
end

function tenueStaffOnService(model)
    clothesSkin = {}
    if model == GetHashKey("mp_m_freemode_01") then
        clothesSkin = {
            ['bags_1'] = 0, ['bags_2'] = 0,
            ['tshirt_1'] = 15, ['tshirt_2'] = 2,
            ['torso_1'] = 178, ['torso_2'] = couleur,
            ['arms'] = 31,
            ['pants_1'] = 77, ['pants_2'] = couleur,
            ['shoes_1'] = 55, ['shoes_2'] = couleur,
            ['mask_1'] = 0, ['mask_2'] = 0,
            ['bproof_1'] = 0,
            ['chain_1'] = 0,
            ['helmet_1'] = 91, ['helmet_2'] = couleur,
        }
    else
        clothesSkin = {
            ['bags_1'] = 0, ['bags_2'] = 0,
            ['tshirt_1'] = 31, ['tshirt_2'] = 0,
            ['torso_1'] = 180, ['torso_2'] = couleur,
            ['arms'] = 36, ['arms_2'] = 0,
            ['pants_1'] = 79, ['pants_2'] = couleur,
            ['shoes_1'] = 58, ['shoes_2'] = couleur,
            ['mask_1'] = 0, ['mask_2'] = 0,
            ['bproof_1'] = 0,
            ['chain_1'] = 0,
            ['helmet_1'] = 90, ['helmet_2'] = couleur,
        }
    end
    for k,v in pairs(clothesSkin) do
        TriggerEvent("skinchanger:change", k, v)
    end
end

function MarqueurVehicle(colorR, colorG, colorB)
    local pos = GetEntityCoords(ESX.Game.GetClosestVehicle())
    local _, distanceveh = ESX.Game.GetClosestVehicle()
    if distanceveh <= 4.0 then
    DrawMarker(21, pos.x, pos.y, pos.z+1.3, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.2, 0.2, colorR, colorG, colorB, 200, 0, 1, 2, 1, nil, nil, 0)
    end
end

function SpectatePlayer(targetPed, target)
    local playerPed = PlayerPedId()
	enable = true
	if targetPed == playerPed then enable = false end
    if enable then
        local targetx,targety,targetz = table.unpack(GetEntityCoords(targetPed, false))
        RequestCollisionAtCoord(targetx,targety,targetz)
        NetworkSetInSpectatorMode(true, targetPed)
    else
        local targetx,targety,targetz = table.unpack(GetEntityCoords(targetPed, false))
        RequestCollisionAtCoord(targetx,targety,targetz)
        NetworkSetInSpectatorMode(false, targetPed)
    end
end

function getCamDirection()
	local heading = GetGameplayCamRelativeHeading() + GetEntityHeading(GetPlayerPed(-1))
	local pitch = GetGameplayCamRelativePitch()
	local coords = vector3(-math.sin(heading * math.pi / 180.0), math.cos(heading * math.pi / 180.0), math.sin(pitch * math.pi / 180.0))
	local len = math.sqrt((coords.x * coords.x) + (coords.y * coords.y) + (coords.z * coords.z))
	if len ~= 0 then
		coords = coords / len
	end
	return coords
end

 function initializeInvis()
    Citizen.CreateThread(function()
        while invisible do
            SetEntityVisible(GetPlayerPed(-1), 0, 0)
            NetworkSetEntityInvisibleToNetwork(GetPlayerPed(-1), 1)
            Citizen.Wait(1)
        end
    end)
end

function initializeNoclip()
    Citizen.CreateThread(function()
        while noclip do
            HideHudComponentThisFrame(19)
            local pCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local camCoords = getCamDirection()
            SetEntityVelocity(GetPlayerPed(-1), 0.01, 0.01, 0.01)
            SetEntityCollision(GetPlayerPed(-1), 0, 1)

            if IsControlPressed(0, 32) then
                pCoords = pCoords + (NoClipSpeed * camCoords)
            end

            if IsControlPressed(0, 269) then
                pCoords = pCoords - (NoClipSpeed * camCoords)
            end

            if IsControlPressed(1, 15) then
                NoClipSpeed = NoClipSpeed + 0.5
            end
            if IsControlPressed(1, 16) then
                NoClipSpeed = NoClipSpeed - 0.5
                if NoClipSpeed < 0 then
                    NoClipSpeed = 0
                end
            end
            SetEntityCoordsNoOffset(GetPlayerPed(-1), pCoords, true, true, true)
            Citizen.Wait(0)
        end
    end)
end

function markertp()
    local playerPed = PlayerPedId()
    local WaypointHandle = GetFirstBlipInfoId(8)
  
    if DoesBlipExist(WaypointHandle) then
      local coord = Citizen.InvokeNative(0xFA7C7F0AADF25D09, WaypointHandle, Citizen.ResultAsVector())
      SetEntityCoordsNoOffset(playerPed, coord.x, coord.y, -199.9, false, false, false, true)
      ESX.ShowNotification("Vous vous êtes téléporter avec ~g~succès~s~ !")
    else
        ESX.ShowNotification("~r~STOP !~s~\nVous n'avez pas de ~r~marker~s~")
    end
end

function GiveMoneyByStaff() local amount = KeyboardInput("KREEZOX_BOX_AMOUNT", "Somme ? (Cash)", "", 8) if amount ~= nil then amount = tonumber(amount) if type(amount) == 'number' then TGSE('YazhuAdmin:CashGiveByStaff', amount) end end end
function GiveBankByStaff() local amount = KeyboardInput("KREEZOX_BOX_AMOUNT", 'Somme ? (Banque)', "", 8) if amount ~= nil then amount = tonumber(amount) if type(amount) == 'number' then TGSE('YazhuAdmin:BankGiveByStaff', amount) end end end
function GiveSaleByStaff() local amount = KeyboardInput("KREEZOX_BOX_AMOUNT", 'Somme ? (Argent Sale)', "", 8) if amount ~= nil then amount = tonumber(amount) if type(amount) == 'number' then TGSE('YazhuAdmin:SaleGiveByStaff', amount) end end end
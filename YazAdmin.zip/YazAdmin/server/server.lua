ESX = nil
local reportTable = {}
warnedPlayers = {}
players = {}
local items = {}

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


local function getLicense(source)
    if (source ~= nil) then
        local identifiers = {}
        local playerIdentifiers = GetPlayerIdentifiers(source)
        for _, v in pairs(playerIdentifiers) do
            local before, after = playerIdentifiers[_]:match("([^:]+):([^:]+)")
            identifiers[before] = playerIdentifiers
        end
        return identifiers
    end
end

Citizen.CreateThread(function()
    MySQL.Async.fetchAll('SELECT * FROM items', {}, function(result)
        items = result
    end)
end)

ESX.RegisterServerCallback('YazhuAdmin:getJobs', function(source, cb)
    MySQL.Async.fetchAll('SELECT * FROM jobs ORDER BY label ASC', {}, function(result)
        cb(result)
    end)
end)

RegisterCommand('report', function(source, args, rawCommand)
	local xPlayer = ESX.GetPlayerFromId(source)
    local NomDuMec = xPlayer.getName()
    local idDuMec = source
    local RaisonDuMec = table.concat(args, " ")
    if #RaisonDuMec <= 1 then
        TriggerClientEvent("esx:showNotification", source, "<C>~r~Veuillez rentrer une raison valable")
    else
        TriggerClientEvent("esx:showNotification", source, "<C>~g~Votre report a bien été envoyer")
        TriggerClientEvent("YazhuAdmin:Open/CloseReport", -1, 1)
        if xPlayer.getGroup() == "admin" or "mod" then
        TriggerClientEvent("esx:showNotification", 1 , "<C>Nouveau report du joueur ~o~"..GetPlayerName(source).."~s~ !")
        table.insert(reportTable, {
            id = idDuMec,
            nom = NomDuMec,
            args = RaisonDuMec,
        })
        end
    end
end, false)

ESX.RegisterServerCallback('YazhuAdmin:infoReport', function(source, cb)
    cb(reportTable)
end)

ESX.RegisterServerCallback('YazhuAdmin:getGroupOfPlayer', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local group = xPlayer.getGroup()
	cb(group)
end)

ESX.RegisterServerCallback('Greed:retrieveStaffPlayers', function(playerId, cb)
    local playersadmin = {}
    local xPlayers = ESX.GetPlayers()

    for i=1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        if xPlayer.getGroup() ~= "user" then
            table.insert(playersadmin, {
                id = "0",
                group = xPlayer.getGroup(),
                source = xPlayer.source,
                jobs = xPlayer.getJob().name,
                name = xPlayer.getName()
            })
        end
    end
    cb(playersadmin)
end)

ESX.RegisterServerCallback('YazhuAdmin:getPlayerInventory', function(source, cb, target)
    local xPlayer = ESX.GetPlayerFromId(target)
    local name   = xPlayer.getName()
	local Liquide = xPlayer.getMoney()
	local Sale = xPlayer.getAccount('black_money').money
	local Bank = xPlayer.getAccount('bank').money
    local job   = xPlayer.job.label.." ~r~-~s~ "..xPlayer.job.grade_label
    local job2   = xPlayer.job2.label.." ~r~-~s~ "..xPlayer.job2.grade_label
    local items = xPlayer.inventory
	cb({
        name = name,
        Liquide = Liquide,
        Sale = Sale,
        Bank = Bank,
        job  = job,
        job2 = job2,
		items = items,
		weapons = xPlayer.getLoadout(),
        steamid = xPlayer.identifier,
	})
end)

RegisterServerEvent('YazhuAdmin:annonce')
AddEventHandler('YazhuAdmin:annonce', function(announce)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
    if xPlayer.getGroup() ~= "user" then
        local xPlayers = ESX.GetPlayers()
        for i = 1, #xPlayers, 1 do
            local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
            TriggerClientEvent("esx:showNotification", xPlayers[i], announce)
        end
    else
        TriggerEvent("BanSql:ICheatServer", source, "\n\nFaille trouvé ! Venez en BDA sur notre discord .")
    end
end)

AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)
    local _src = source
    deferrals.defer()
    deferrals.update("Vérification des warn...")
    Wait(2500)
    local license = getLicense(_src)
    if warnedPlayers[license] and warnedPlayers[license] > 2 then
        deferrals.done("Vous avez 3 avertissements actif, vous ne pouvez donc pas vous connecter avant le prochain reboot")
    else
        deferrals.done()
    end
end)

RegisterServerEvent("YazhuAdmin:CloseReport")
AddEventHandler("YazhuAdmin:CloseReport", function(nomMec, raisonMec)
    TriggerClientEvent("YazhuAdmin:Open/CloseReport", -1, 2, nomMec, raisonMec)
    table.remove(reportTable, id, nom, args)
end)

RegisterNetEvent("YazhuShop:getItems")
AddEventHandler("YazhuShop:getItems", function()
    local _src = source
    TriggerClientEvent("YazhuShop:getItems", _src, items)
end)

RegisterServerEvent("YazhuAdmin:bring")
AddEventHandler("YazhuAdmin:bring",function(IdDuMec, plyPedCoords, lequel)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() == "mod" or xPlayer.getGroup() == "admin" or xPlayer.getGroup() == "superadmin" then
        if lequel == "bring" then
            TriggerClientEvent("YazhuAdmin:bring", IdDuMec, plyPedCoords)
        else
            TriggerClientEvent("YazhuAdmin:bring", plyPedCoords, IdDuMec)
        end
    else
        print('Tu peux pas !')
    end
end)

RegisterNetEvent("YazhuAdmin:Message")
AddEventHandler("YazhuAdmin:Message", function(id, type)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
        TriggerClientEvent("YazhuAdmin:envoyer", id, type)
    else
        TriggerEvent("BanSql:ICheatServer", source, "\n\nFaille trouvé ! Venez en BDA sur notre discord .")
        --TriggerEvent("BanSql:ICheat", "Auto-Cheat Custom Reason",TargetId)
    end
end)

RegisterNetEvent("adminmenu:warn")
AddEventHandler("adminmenu:warn", function(target, reason)
    local source = source
    local license = getLicense(target)
    if warnedPlayers[license] == nil then
        warnedPlayers[license] = 0
    end
    warnedPlayers[license] = (warnedPlayers[license] + 1)
    TriggerClientEvent("esx:showNotification", source, ("~g~Warn envoyé à %s"):format(GetPlayerName(target)))
    TriggerClientEvent("esx:showNotification", target, ("~r~Vous avez reçu un avertissement~s~: %s"):format(reason))
    TriggerClientEvent("adminmenu:receivewarn", target, reason)
    print(json.encode(warnedPlayers[license]))
    if warnedPlayers[license] > 2 then
        DropPlayer(target, "3 Avertissements atteints ! Vous pourrez vous reconnecter au prochain reboot.")
    end
    print(warnedPlayers[license])
end)

RegisterNetEvent("YazhuAdmin:kick")
AddEventHandler("YazhuAdmin:kick", function(id,mess)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
        TriggerClientEvent("esx:showNotification", source, "Vous avez kick ~y~"..GetPlayerName(id))
        DropPlayer(id, "\n\nVous avez été expulsé : \""..mess.."\", par "..GetPlayerName(source))
    else
        TriggerEvent("BanSql:ICheatServer", source, "\n\nFaille trouvé ! Venez en BDA sur notre discord .")
    end
end)

RegisterServerEvent("YazhuAdmin:admin:freezelejoueur")
AddEventHandler("YazhuAdmin:admin:freezelejoueur", function(srccc, state)
    TriggerClientEvent("YazhuAdmin:freezeplayer", srccc, state)
end)

RegisterServerEvent("YazhuAdmin:RetryItems")
AddEventHandler("YazhuAdmin:RetryItems", function(target, args1, args2, type)
local xPlayer = ESX.GetPlayerFromId(target)
    xPlayer.removeInventoryItem(args1, args2)
end)

RegisterNetEvent("YazhuAdmin:RemboursementItem")
AddEventHandler("YazhuAdmin:RemboursementItem", function(id,item,qty)
    local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    xPlayer.addInventoryItem(item,qty,id)
end)

RegisterServerEvent("YazhuAdmin:CashGiveByStaff")
AddEventHandler("YazhuAdmin:CashGiveByStaff", function(money)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local total = money
	xPlayer.addAccountMoney('money', total)
	local item = '$ (Cash)'
	local message = '~p~Administration~w~\n~g~Recu : '
	TriggerClientEvent('esx:showNotification', _source, message .. total .. item)
	TriggerEvent("esx:admingivemoneyalert",xPlayer.name,total)
end)

RegisterServerEvent("YazhuAdmin:BankGiveByStaff")
AddEventHandler("YazhuAdmin:BankGiveByStaff", function(money)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local total = money
	xPlayer.addAccountMoney('bank', total)
	local item = '$ (Banque)'
	local message = '~p~Administration~w~\n~b~Recu : '
	TriggerClientEvent('esx:showNotification', _source, message .. total .. item)
	TriggerEvent("esx:admingivemoneyalert",xPlayer.name,total)
end)

RegisterServerEvent("YazhuAdmin:SaleGiveByStaff")
AddEventHandler("YazhuAdmin:SaleGiveByStaff", function(money)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local total = money
	xPlayer.addAccountMoney('black_money', total)
	local item = '$ (Sale)'
	local message = '~p~Administration~w~\n~r~Recu : '
	TriggerClientEvent('esx:showNotification', _source, message..total..item)
	TriggerEvent("esx:admingivemoneyalert",xPlayer.name,total)
end)

RegisterServerEvent("YazhuAdmin:bring")
AddEventHandler("YazhuAdmin:bring", function(admin_coords, target_id)
    local Source = source
    local xPlayer = ESX.GetPlayerFromId(Source)
    if xPlayer.getGroup() ~= "user" then
        TriggerClientEvent("YazhuAdmin:teleport_player", target_id, admin_coords)
    else
        TriggerEvent("BanSql:ICheatServer", source, "\n\nFaille trouvé ! Venez en BDA sur notre discord .")
    end
end)

RegisterServerEvent("YazhuAdmin:bringplayer")
AddEventHandler("YazhuAdmin:bringplayer",function(IdSelected, plyPedCoords)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
        TriggerClientEvent("YazhuAdmin:bringplayer", IdSelected, plyPedCoords)
    end
end)

RegisterServerEvent("YazhuAdmin:bringplayer")
AddEventHandler("YazhuAdmin:bringplayer",function(IdSelected, plyPedCoords)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
        TriggerClientEvent("YazhuAdmin:bringplayer", IdSelected, plyPedCoords)
    else
        TriggerEvent("BanSql:ICheatServer", source, "\n\nFaille trouvé ! Venez en BDA sur notre discord .")
    end
end)

RegisterNetEvent("YazhuAdmin:SetJobsPlayer")
AddEventHandler("YazhuAdmin:SetJobsPlayer", function(player, job,jobLabel, grade)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() ~= "user" then
        local xTarget = ESX.GetPlayerFromId(player)
        xTarget.setJob(job, grade)
        TriggerClientEvent("esx:showNotification", player, "<C>~o~SetJob~s~ fais par ~b~"..xPlayer.name)
        TriggerClientEvent("esx:showNotification", player, "<C>~o~SetJob~s~\nJob : ~b~"..jobLabel.."~s~\nGrade : ~b~"..grade)
        TriggerClientEvent("esx:showNotification", source, "<C>Vous venez de ~y~SetJob~s~ ~b~"..xTarget.name)
    end
end)

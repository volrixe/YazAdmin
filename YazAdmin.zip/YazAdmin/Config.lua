Config = {
    NameMenu = "Ton serveur",
    InitESX = 'esx:getSharedObject',
    ToucheMenu = "F10",
    OpenMenuChat = "-openAdminMenu",
    TriggerRevive = "esx_ambulancejob:revive",
    TriggerBan = "",
    AllowedWaypoints = {
        Index = 1, "Parking Central", "Commissariat", "Hôpital"
    },
    TeleportList = {
        Pos = {
             Pc = {
                {pospc = vector3(221.83, -812.19, 30.84)}
             },
             Fourriere = {
                {posf = vector3(408.59, -1625.65, 29.29)}
            },
        },
    }
}



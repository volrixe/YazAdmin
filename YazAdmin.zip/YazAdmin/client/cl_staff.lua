ESX = nil

local TGSE, staffservice, label, onservice, MenuForAdministration, ServersIdSession , label2 , labelnoclip, nomcheck, colorVar, actualColor, colors, gamerTags, menuColor, MenuPersoList= TriggerServerEvent, false, "~g~Activer son service", "~r~Inactif", false, {}, "→ ~s~Afficher les noms", "→ ~s~Activer Noclip~s~", false, "~s~", 1, {"~r~", "~b~", "~g~", "~y~", "~p~","~c~","~o~"}, {}, {255, 255, 255}, {List = 1, List1 = 1, List2 = 1}
local items , reportselect , reportlist, invItems, invMoney, invName, invJob, invWeapon, MenuStaff, AllMenuToChange, getListjobs, jobs, labelFreeze = {}, false, {},{}, {},{},{}, {}, {PlayersStaff = {},}, nil, {}, {}, "→ Freeze le joueur"
noclip  = false
PercentageColor1 = 0
PercentageColor2 = 0
PercentageColor3 = 0
CreateThread(function() 
    while ESX == nil do 
        TriggerEvent(''..Config.InitESX, function(obj) ESX = obj end) 
        Wait(10)
        while ESX.GetPlayerData().job == nil do
            Wait(10)
        end
        if ESX.IsPlayerLoaded() then
            ESX.PlayerData = ESX.GetPlayerData()
            ESX.TriggerServerCallback('YazhuAdmin:getGroupOfPlayer', function(group)
                playergroup = group
                ReloadColor()
                getItems()
                MenuStaff.PlayersStaff = MenuStaff:OnGetStaffPlayers()
            end)
        end
    end 
end)

local AdminMenu = RageUI.CreateMenu(Config.NameMenu, "Actions divers(es)") 
local listeplayer = RageUI.CreateSubMenu(AdminMenu, "Joueurs", "Liste des joueurs") 
local actionjoueur = RageUI.CreateSubMenu(listeplayer, "Joueurs", "Actions sur le joueur") 
local actionvehicle = RageUI.CreateSubMenu(AdminMenu, "Véhicule", "Actions sur des vehicule") 
local advancedoption = RageUI.CreateSubMenu(AdminMenu, "Staff", "Actions avancés") 
local personneladmin = RageUI.CreateSubMenu(AdminMenu, "Personnel", "Options personnel") 
local ColorMenuStaff = RageUI.CreateSubMenu(AdminMenu, "Personnel", "Changer la couleur") 
local ReportMenuForstaff = RageUI.CreateSubMenu(AdminMenu, "Report", "Liste des reports")  
local SupplInfoAdmin = RageUI.CreateSubMenu(actionjoueur, "Informations", "Informations supplémentaire") 
local inforeport = RageUI.CreateSubMenu(AdminMenu, "Informations", "Informations report") 
local GiveItemId = RageUI.CreateSubMenu(actionjoueur, "Remboursement", "Rembourser un item")
local JobsSetjobBystaff = RageUI.CreateSubMenu(actionjoueur, "Jobs", "Changez le job")
AdminMenu:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})listeplayer:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})actionjoueur:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})actionvehicle:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})advancedoption:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})personneladmin:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})ColorMenuStaff:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})ReportMenuForstaff:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})SupplInfoAdmin:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})inforeport:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})GiveItemId:AddInstructionButton({[1] = GetControlInstructionalButton(0, 289, 0), [2] = "Raccourci Noclip"})
ColorMenuStaff.EnableMouse = true
AdminMenu.Closed = function () MenuForAdministration = false end
local AllMenu = {AdminMenu,listeplayer,actionjoueur,actionvehicle,advancedoption,personneladmin,ColorMenuStaff, ReportMenuForstaff, SupplInfoAdmin, inforeport, GiveItemId, JobsSetjobBystaff}
local function initializeText() CreateThread(function() while staffservice do Wait(1) if IsControlPressed(1, 21) and IsControlPressed(1, 46) then if tpmarker then markertp() else ESX.ShowNotification("Vous ne pouvez pas vous téléportez vous n'êtes pas en ~r~Staff Mode~s~ !") end end Visual.Subtitle(colors[actualColor].."Mode administration actif~s~\n" ..#reportlist.. " report actif") end end) end
function getInfoReport() local info = {} ESX.TriggerServerCallback('YazhuAdmin:infoReport', function(info) reportlist = info end) end
function GetJobs() getListjobs = {} ESX.TriggerServerCallback("YazhuAdmin:getJobs", function(jobs) for k,v in pairs(jobs) do table.insert(getListjobs,  {name = v.name, label = v.label}) end end) end
function MenuStaff:OnGetStaffPlayers()
    local clientPlayers = false;
    ESX.TriggerServerCallback('Greed:retrieveStaffPlayers', function(players)
        clientPlayers = players
    end)
    while not clientPlayers do
        Wait(0)
    end
    return clientPlayers
end

CreateThread(function()
    while true do
        Wait(500)
        for k,v in pairs(GetActivePlayers()) do
            local found = false
            for _,j in pairs(ServersIdSession) do
                if GetPlayerServerId(v) == j then
                    found = true
                end
            end
            if not found then
                table.insert(ServersIdSession, GetPlayerServerId(v))
            end
        end
    end
end)

function GetAllInformationsPlayers()
    invItems = {}
    invWeapon = {}
    invJob = {}
    invMoney = {}
    invName = {}
    ESX.TriggerServerCallback('YazhuAdmin:getPlayerInventory', function(inventory)
        for i=1, #inventory.items, 1 do
            local item = inventory.items[i]
            if item.count > 0 then
                table.insert(invItems, {label = '~s~' .. item.label .. ' ~b~x' .. item.count, type = 'item_standard', value = item.name})
            end
        end
        for i=1, #inventory.weapons, 1 do
            local weapon = inventory.weapons[i]
            table.insert(invWeapon, { label = weapon.label .. ' avec ~b~' .. weapon.ammo..' munitions', type  = 'item_weapon', value = weapon.name, ammo  = weapon.ammo })
        end
        table.insert(invJob, {job = inventory.job, job2 = inventory.job2})
        table.insert(invMoney, {cash = "~g~"..inventory.Liquide.."$",bank = "~b~"..inventory.Bank.."$",dirty = "~r~"..inventory.Sale.."$"})
        table.insert(invName, {label = inventory.name})
    end, IdSelected)
end

CreateThread(function() Wait(1000) menuColor[1] = GetResourceKvpInt("menuR") menuColor[2] = GetResourceKvpInt("menuG") menuColor[3] = GetResourceKvpInt("menuB") ReloadColor() end)
function ReloadColor()
    CreateThread(function()
        if AllMenuToChange == nil then
            AllMenuToChange = {}
            
            for index in pairs(AllMenu) do
                
                table.insert(AllMenuToChange, AllMenu[index])
            end
        end
        for k,v in pairs(AllMenuToChange) do
            
            v:SetRectangleBanner(menuColor[1], menuColor[2], menuColor[3], 255)
        end
    end)
end

OpenAdminMenu = function()
    if MenuForAdministration == false then
        if MenuForAdministration then
            MenuForAdministration = false
        else
            MenuForAdministration = true
            getInfoReport()
            CreateThread(function()
                while MenuForAdministration do
                     Wait(800)
                     if colorVar == "~s~" then colorVar = "~r~" else colorVar = "~s~" end
                end
                end)
                CreateThread(function()
                while MenuForAdministration do
                     if MenuForAdministration then
                          Wait(500)
                          actualColor = actualColor + 1
                          if actualColor > #colors then actualColor = 1 end
                          else
                          actualColor = 1
                          colors = "~r~"
                          break
                     end
                end
           end)
            RageUI.Visible(AdminMenu, true)
            CreateThread(function()
                while MenuForAdministration do
                    Wait(1)
                    if ShowName then
                        local pCoords = GetEntityCoords(GetPlayerPed(-1), false)
                        for _, v in pairs(GetActivePlayers()) do
                            local otherPed = GetPlayerPed(v)
                                if #(pCoords - GetEntityCoords(otherPed, false)) < 250.0 then
                                    gamerTags[v] = CreateFakeMpGamerTag(otherPed, "["..GetPlayerServerId(v).."] - "..GetPlayerName(v), true, false, '', 2)
                                    SetMpGamerTagAlpha(gamerTags[v], 2, 255)
                                    SetMpGamerTagVisibility(gamerTags[v], 2, true)
                                else
                                    RemoveMpGamerTag(gamerTags[v])
                                    gamerTags[v] = nil
                                end
                            end
                        else
                            for _, v in pairs(GetActivePlayers()) do
                                RemoveMpGamerTag(gamerTags[v])
                            end
                        end
                    if joueursblips then
                        for _, player in pairs(GetActivePlayers()) do
                            local found = false
                            if player ~= PlayerId() then
                                local ped = GetPlayerPed(player)
                                local blip = GetBlipFromEntity( ped )
                                if not DoesBlipExist( blip ) then
                                    blip = AddBlipForEntity(ped)
                                    SetBlipCategory(blip, 7)
                                    SetBlipScale( blip,  0.85 )
                                    ShowHeadingIndicatorOnBlip(blip, true)
                                    SetBlipSprite(blip, 1)
                                    SetBlipColour(blip, 0)
                                end
                                
                                SetBlipNameToPlayerName(blip, player)
                                
                                local veh = GetVehiclePedIsIn(ped, false)
                                local blipSprite = GetBlipSprite(blip)
                                
                                if IsEntityDead(ped) then
                                    if blipSprite ~= 303 then
                                        SetBlipSprite( blip, 303 )
                                        SetBlipColour(blip, 1)
                                        ShowHeadingIndicatorOnBlip( blip, false )
                                    end
                                elseif veh ~= nil then
                                    if IsPedInAnyBoat( ped ) then
                                        if blipSprite ~= 427 then
                                            SetBlipSprite( blip, 427 )
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, false )
                                        end
                                    elseif IsPedInAnyHeli( ped ) then
                                        if blipSprite ~= 43 then
                                            SetBlipSprite( blip, 43 )
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, false )
                                        end
                                    elseif IsPedInAnyPlane( ped ) then
                                        if blipSprite ~= 423 then
                                            SetBlipSprite( blip, 423 )
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, false )
                                        end
                                    elseif IsPedInAnyPoliceVehicle( ped ) then
                                        if blipSprite ~= 137 then
                                            SetBlipSprite( blip, 137 )
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, false )
                                        end
                                    elseif IsPedInAnySub( ped ) then
                                        if blipSprite ~= 308 then
                                            SetBlipSprite( blip, 308 )
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, false )
                                        end
                                    elseif IsPedInAnyVehicle( ped ) then
                                        if blipSprite ~= 225 then
                                            SetBlipSprite( blip, 225 )
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, false )
                                        end
                                    else
                                        if blipSprite ~= 1 then
                                            SetBlipSprite(blip, 1)
                                            SetBlipColour(blip, 0)
                                            ShowHeadingIndicatorOnBlip( blip, true )
                                        end
                                    end
                                else
                                    if blipSprite ~= 1 then
                                        SetBlipSprite( blip, 1 )
                                        SetBlipColour(blip, 0)
                                        ShowHeadingIndicatorOnBlip( blip, true )
                                    end
                                end
                                if veh then
                                    SetBlipRotation( blip, math.ceil( GetEntityHeading( veh ) ) )
                                else
                                    SetBlipRotation( blip, math.ceil( GetEntityHeading( ped ) ) )
                                end
                            end
                        end
                    end

                    RageUI.IsVisible(AdminMenu, function()

                        RageUI.Separator("Service : "..onservice)
                        RageUI.Checkbox(label, nil, checkbox, {}, {
                            onChecked = function()
                                label = "~r~Quitter son service"
                                onservice = "~g~Actif"
                                staffservice = true
                                tpmarker = true 
                                noclip = false
                                initializeText()
                                listJoueurs = true
                                joueursblips = true 
                                tenueStaffOnService(GetEntityModel(PlayerPedId()))
                            end,
                            onUnChecked = function()
                                label = "~g~Activer son service"
                                onservice = "~r~Inactif"
                                staffservice = false
                                noclip = false
                                tpmarker = false
                                invisible = false
                                listJoueurs = false
                                joueursblips = false
                                FreezeEntityPosition(GetPlayerPed(-1), false)
                                SetEntityCollision(GetPlayerPed(-1), 1, 1)
                                SetEntityVisible(GetPlayerPed(-1), 1, 0)
                                NetworkSetEntityInvisibleToNetwork(GetPlayerPed(-1), 0)
                                ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                                    TriggerEvent('skinchanger:loadSkin', skin)
                                end)
                            end,
                            onSelected = function(Index)
                                checkbox = Index
                            end
                        })

                        RageUI.Separator("Staff en ligne : ~o~" ..#MenuStaff.PlayersStaff)

                        if staffservice then

                        RageUI.Button(colors[actualColor].."→~s~ Options personnel", nil, {RightLabel = "→→"}, true , {
                            onSelected = function ()
                            end
                        },personneladmin)

                        RageUI.Separator("↓ ~g~Gestion serveur~s~ ↓")
                        RageUI.Button(colors[actualColor].."→~s~ Gestion des joueurs", nil, {RightLabel = "→→"}, true , {
                            onSelected = function ()
                            end
                        },listeplayer)

                        RageUI.Button(colors[actualColor].."→~s~ Gestion de report(s)", "Report disponible : "..colors[actualColor] ..#reportlist, {RightLabel = "→→"}, true , {
                            onSelected = function ()
                                getInfoReport()
                            end
                        }, ReportMenuForstaff)
                    
                        RageUI.Button(colors[actualColor].."→~s~ Gestion véhicule", nil, {RightLabel = "→→"}, true , {
                            onSelected = function ()
                            end
                        },actionvehicle);
                        if group == "admin" or "superadmin" then
                        RageUI.Button(colors[actualColor].."→~s~ Gestion avancée", nil, {RightLabel = "→→"}, true , {
                            onSelected = function ()
                            end
                        },advancedoption);
                    else
                        RageUI.Button(colors[actualColor].."→~s~ Gestion avancée", nil, {RightLabel = "→→"}, false , {})
                    end

                        end
                    end)
                  RageUI.IsVisible(ColorMenuStaff, function()
                    RageUI.PercentagePanel(PercentageColor1,"Rouge", '0', '255', {
                                
                        onProgressChange = function(Percentage)
                            PercentageColor1 = Percentage
                            menuColor[1] = math.floor(Percentage*255)
                            ReloadColor()
                        end
                    })
                    RageUI.PercentagePanel(PercentageColor2,"Vert", '0', '255', {
                        
                        onProgressChange = function(Percentage)
                            PercentageColor2 = Percentage
                            menuColor[2] = math.floor(Percentage*255)
                            ReloadColor()
                        end
                    })
                    RageUI.PercentagePanel(PercentageColor3,"Bleu", '0', '255', {
                        
                        onProgressChange = function(Percentage)
                            PercentageColor3 = Percentage
                            menuColor[3] = math.floor(Percentage*255)
                            ReloadColor()
                        end
                    })
                    RageUI.Button("Sauvegarder la couleur", nil, {RightLabel = "→→"}, true , {
                                
                        onSelected = function ()
                            SetResourceKvpInt("menuR", menuColor[1])
                            SetResourceKvpInt("menuG", menuColor[2])
                            SetResourceKvpInt("menuB", menuColor[3])
                            ReloadColor()
                            RageUI.GoBack()
                        end
                    })
                  end)

                    RageUI.IsVisible(personneladmin, function()
                        RageUI.Checkbox(colors[actualColor]..""..labelnoclip, "Molette vers le bas ou vers le haut pour diminuer/augmenter la vitesse.", noclip, {}, {
                            onChecked = function()
                                noclip = true
                                invisible = true 
                                labelnoclip = "~r~Désactiver Noclip~s~"
                                initializeNoclip()
                                initializeInvis()
                                FreezeEntityPosition(GetPlayerPed(-1), true)
                            end,
                            onUnChecked = function()
                                noclip = false
                                invisible = false
                                labelnoclip = "→~s~ Activer Noclip"
                                FreezeEntityPosition(GetPlayerPed(-1), false)
                                SetEntityCollision(GetPlayerPed(-1), 1, 1)
                                SetEntityVisible(GetPlayerPed(-1), 1, 0)
                                NetworkSetEntityInvisibleToNetwork(GetPlayerPed(-1), 0)
                            end,
                        })

                        RageUI.Checkbox(colors[actualColor]..""..label2, nil , nomcheck, {}, {
                            onChecked = function()
                                nomcheck = true
                                label2 = "~r~Désactiver les noms~s~"
                                ShowName = true
                            end,
                            onUnChecked = function()
                                nomcheck = false
                                ShowName = false
                                label2 = "→~s~ Activer les noms~s~"
                                for _,v in pairs(GetActivePlayers()) do
                                    RemoveMpGamerTag(gamerTags[v])
                                end
                            end,
                        })

                        RageUI.List(colors[actualColor].."→~s~ Se give de l'argent", {"~g~Liquide~s~", "~b~Banque~s~", "~r~Sale~s~"}, MenuPersoList.List2, nil, {}, true, {
                            onListChange = function(i, Item)
                                MenuPersoList.List2 = i;
                            end,
                            onSelected = function (i, Item)
                                if i == 1 then
                                    GiveMoneyByStaff()
                                elseif i == 2 then
                                    GiveBankByStaff()
                                elseif i == 3 then
                                    GiveSaleByStaff()
                                end
                            end
                        })

                        if group == "admin" or "superadmin" then

                        RageUI.Button(colors[actualColor].."→~s~ TP au marker", nil, {RightLabel = "→→"}, true, {
                            onSelected = function()
                                local playerPed = PlayerPedId()
                                local WaypointHandle = GetFirstBlipInfoId(8)
                                if DoesBlipExist(WaypointHandle) then
                                    local coord = Citizen.InvokeNative(0xFA7C7F0AADF25D09, WaypointHandle, Citizen.ResultAsVector())
                                    SetEntityCoordsNoOffset(playerPed, coord.x, coord.y, -199.9, false, false, false, true)
                                else
                                    ESX.ShowNotification("<C>~r~Veuillez placer un marqueur sur la map")
                                end
                            end
                        })
                    else
                        RageUI.Button("TP au marker", nil, {RightLabel = "→→"}, false, {})
                    end
                    
                    RageUI.Button(colors[actualColor].."→~s~ Changer la couleur du menu", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                        end
                    },ColorMenuStaff)
                end)

                    RageUI.IsVisible(actionvehicle, function()
                        local pos = GetEntityCoords(PlayerPedId())
                        local veh, dst = ESX.Game.GetClosestVehicle({x = pos.x, y = pos.y, z = pos.z})
                        if dst ~= nil then RageUI.Separator("~s~Véhicule le plus proche: ~b~"..math.floor(dst+0.5).."m") end

                        if not IsPedInAnyVehicle(PlayerPedId(), -1) then
                        RageUI.Button(colors[actualColor].."→~s~ Spawn un véhicule", nil, {RightLabel = "→→"}, not codesCooldown , {
                            onSelected = function()
                                codesCooldown = true
                                local model = KeyboardInput('', (''), '', 50)
                                    if model ~= nil then
                                    model = GetHashKey(model)
                                    if IsModelValid(model) then
                                        RequestModel(model)
                                        local co = GetEntityCoords(PlayerPedId())
                                        while not HasModelLoaded(model) do Wait(10) end
                                        local veh = CreateVehicle(model, co.x, co.y, co.z, GetEntityHeading(PlayerPedId()), true, false)
                                        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
                                        RageUI.GoBack()
                                        SetTimeout(5000, function() codesCooldown = false end)
                                    end
                                end
                            end
                        })
                    else
                        RageUI.Button("Spawn un véhicule", nil, {RightLabel = "→→"}, false , {})
                    end
                    

                    RageUI.Button(colors[actualColor].."→~s~ Réparer le véhicule", nil, {RightLabel = "→→"}, true, {
                        onActive = function()
                            MarqueurVehicle(66, 158, 245)
                        end,
                        onSelected = function()
                            local co = GetEntityCoords(PlayerPedId())
                            local veh, dst = ESX.Game.GetClosestVehicle({x = co.x, y = co.y, z = co.z})
                            if veh ~= nil then 
                                SetVehicleEngineHealth(veh, 1000)
                                SetVehicleEngineOn(veh, true, true )
                                SetVehicleFixed(veh)
                            end
                        end,
                    })
        
        
                    RageUI.Button(colors[actualColor].."→~s~ Supprimer le véhicule", nil, {RightLabel = "→→"}, true, {
                        onActive = function()
                            MarqueurVehicle(66, 158, 245)
                        end,
                        onSelected = function()
                            local co = GetEntityCoords(PlayerPedId())
                            local veh, dst = ESX.Game.GetClosestVehicle({x = co.x, y = co.y, z = co.z})
                            if veh ~= nil then DeleteEntity(veh) end
                        end,
                    })
                            if not IsPedInAnyVehicle(PlayerPedId(), -1) then
                            RageUI.Button(colors[actualColor].."→~s~ Retourner le véhicule", nil, {RightLabel = "→→"}, true , {
                                onActive = function()
                                    MarqueurVehicle(66, 158, 245)
                                end,
                                onSelected = function()
                                    local plyCoords = GetEntityCoords(PlayerPedId())
                                    local newCoords = plyCoords + vector3(0.0, 2.0, 0.0)
                                    local closestVeh = GetClosestVehicle(plyCoords, 5.0, 0, 70)
                                    if IsPedInAnyVehicle(PlayerPedId(), -1) then
                                        ESX.ShowNotification("<C>~r~Veuillez sortir du véhicule pour effectuer cette action !")
                                    else
                                        SetEntityCoords(closestVeh, newCoords)
                                    end
                                end
                            })
                        else
                            RageUI.Button("Retourner le véhicule", nil, {RightLabel = "→→"}, false , {})
                        end

                        if  IsPedInAnyVehicle(PlayerPedId(), -1) then
                            RageUI.Button(colors[actualColor].."→~s~ Changer la plaque", nil, {RightLabel = "→→"}, true , {
                                onActive = function()
                                    MarqueurVehicle(66, 158, 245)
                                end,
                                onSelected = function()
                                local plaqueVehicule = Keyboardput("Plaque", "", 8)
                                 SetVehicleNumberPlateText(GetVehiclePedIsIn(GetPlayerPed(-1), false) , plaqueVehicule)
                                ESX.ShowNotification("Plaque changée en : ~g~"..plaqueVehicule)

                                end
                            })
                        else
                            RageUI.Button("Changer la plaque", "Vous n'êtes pas dans un véhicule", {RightLabel = "→→"}, false , {})
                        end
                    end) 


                    RageUI.IsVisible(advancedoption, function()

                        if group == "admin" or "superadmin" then
                        RageUI.List(colors[actualColor].."→~s~ Annonces", {"Personnalisé", "Reboot"}, MenuPersoList.List, nil, {}, true, {
                            onListChange = function(i, Item)
                                MenuPersoList.List = i;
                            end,
                            onSelected = function (i,item)
                                if i == 1 then
                                    local texte = KeyboardInput("Entrer l' annonce que vous voulez ~r~publier~s~", (''), '', 100)
                                        if texte == "" then 
                                            ESX.ShowNotification("<C>~r~Veuillez entrez un message")
                                        else
                                            TGSE("YazhuAdmin:annonce", "<C>~r~Serveur annonce~s~\n"..texte)
                                            PlaySoundFrontend(-1, "CHARACTER_SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1)
                                        end
                                    elseif i == 2 then
                                        local min = KeyboardInput("Entrer dans ~r~combient de minutes~s~ va reboot le serveur", (''), '', 2)
                                        if min == "" then 
                                            ESX.ShowNotification("<C>~r~Veuillez entrez le temps avant le reboot")
                                        else
                                            TGSE("YazhuAdmin:annonce", "<C>~r~Serveur annonce~s~\nReboot dans ~o~"..min.."min~s~ !")
                                            PlaySoundFrontend(-1, "CHARACTER_SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1)
                                        end
                                    end
                                end
                            })
                        else
                            RageUI.Button("Annonces", nil, {RightLabel = "→→"}, false , {})
                        end
                    end)

                    RageUI.IsVisible(JobsSetjobBystaff, function()
                        RageUI.Button("               [-] Rechercher un ~o~Job",nil,{},true, {
                        onSelected = function()
                            filterjob = KeyboardInput("Entrez un nom d'un ~r~Job~s~ (ENTRER pour tout remettre)", (''), '', 500)
                            if filterjob == "" then
                                ESX.ShowNotification("<C>~r~Administration~s~\nListe des jobs remis .")
                            else
                                if filterjob == nil then
                                    ESX.ShowNotification("<C>~r~Administration~s~\nJob incorrecte")
                                else
                                    ESX.ShowNotification("<C>~r~Administration~s~\nVous avez chercher le job ~r~"..filterjob)
                                end
                            end
                        end
                    })

                    RageUI.Separator("Il y a actuellement ~r~" ..#getListjobs.. "~s~ job en BDD")
                        for k,v in pairs(getListjobs) do
                            if filterjob == nil or string.find(v.label,filterjob) then
                                RageUI.Button(colors[actualColor].."→~s~ "..v.label, "Appuyez pour setjob le joueur :~y~" ..GetPlayerName(GetPlayerFromServerId(IdSelected)), {RightLabel = "→→"}, true, {
                                    onSelected = function()
                                        grade = KeyboardInput("Veuillez entrer le grade que vous voulez ~r~set~s~ ","Grade ?", 6)
                                        if grade ~= nil or grade ~= "" then
                                            grade = tonumber(grade)
                                            if type(grade) == 'number' then
                                            if grade > -1 then
                                                TGSE("YazhuAdmin:SetJobsPlayer", IdSelected, v.name, v.label, grade)
                                            else
                                                ESX.ShowNotification("<C>~r~Action annulé~s~\nvous devez mettre un ~g~grade~s~ valide !")
                                                end
                                            end
                                        end
                                    end
                                }) 
                            end  
                        end
                    end)
                    RageUI.IsVisible(listeplayer, function()

                        players = {}
                        for _, player in pairs(GetActivePlayers()) do
                            local ped = GetPlayerPed(player)
                            table.insert(players, player)
                        end

                        RageUI.Separator("Joueur connecté : ~g~" ..#players.."~s~/128")
                        RageUI.Button("               [-] Rechercher un ~r~ID",nil,{},true, {
                            onSelected = function()
                                filterid = KeyboardInput('Entrez un ~r~ID~s~ (ENTRER pour tout remettre)', (''), '', 100)
                                if filterid == "" then
                                 ESX.ShowNotification("<C>~r~Valeur non précise ou incorrect")
                                else
                                    if filterid == nil then
                                      ESX.ShowNotification("<C>~r~Valeur non précise ou manquante")
                                   
                                    else
                                      ESX.ShowNotification("<C>~r~Administration~s~\nVous avez chercher l'id  ~g~"..filterid)
                                    end
                                end
                            end
                       })

                        for k,v in ipairs(ServersIdSession) do
                            if GetPlayerName(GetPlayerFromServerId(v)) == "**Invalid**" then table.remove(ServersIdSession, k) end
                            if filterid == nil or string.find(v,filterid) then
                                RageUI.Button(colors[actualColor].."→ ~s~(~o~"..v.. "~s~) "..GetPlayerName(GetPlayerFromServerId(v)), nil, {RightLabel = "→→"}, true, {
                                    onSelected = function ()
                                        IdSelected = v
                                    end
                                },actionjoueur);
                            end
                        end
                    end)

                    RageUI.IsVisible(actionjoueur, function()
                        RageUI.Separator("Nom : ~g~"..colors[actualColor].."" ..GetPlayerName(GetPlayerFromServerId(IdSelected)).. "~s~ | Id unique : "..colors[actualColor] ..GetPlayerServerId(PlayerId(IdSelected)).."~s~")
                        RageUI.Button("→ Se téléporter sur lui", nil , {RightLabel = "→→"}, true , {
                            onSelected = function ()
                                SetEntityCoords(PlayerPedId(), GetEntityCoords(GetPlayerPed(GetPlayerFromServerId(IdSelected))))
                                ESX.ShowNotification("<C>Téléportation sur ~o~".. GetPlayerName(GetPlayerFromServerId(IdSelected)).. "~s~ effectué")
                            end
                        })
                        
                        RageUI.Button("→ Téléporter sur vous", nil , {RightLabel = "→→"}, true , {
                            onSelected = function ()
                                local plyPedCoords = GetEntityCoords(PlayerPedId())
                                TGSE('YazhuAdmin:bringplayer', IdSelected, plyPedCoords)
                                ESX.ShowNotification("Vous venez de téléportez ~r~" .. GetPlayerName(GetPlayerFromServerId(IdSelected)).."~s~ à ~r~vous~s~ .")
                            end
                        })
                        
                        RageUI.Button("→ Envoyer un message", nil , {RightLabel = "→→"}, true , {
                            onSelected = function ()
                                local raison = KeyboardInput('Message', ('écrivez votre message'), '', 1000)
                                if raison ~= nil then
                                    raison = tostring(raison)
                                    if type(raison) == 'string' then
                                        TGSE("YazhuAdmin:Message", IdSelected, raison)                                
                                    end
                                end
                                ESX.ShowNotification("Vous venez d'envoyer le message à ~r~" .. GetPlayerName(GetPlayerFromServerId(IdSelected)))
                            end
                        })
                        
                        RageUI.Button("→ Heal", nil , {RightBadge = RageUI.BadgeStyle.Heart}, true , {
                            onSelected = function ()
                               GetEntityHealth(IdSelected)
                               SetEntityHealth(IdSelected, id)
                               ExecuteCommand("heal " ..IdSelected)
                            end
                        })

                        RageUI.Button("→ Revive", nil , {RightBadge = RageUI.BadgeStyle.Heart}, true , {
                            onSelected = function ()
                                TGSE(Config.TriggerRevive, IdSelected)
                                ESX.ShowNotification("Tu as réanimé ~b~"..GetPlayerName(GetPlayerFromServerId(IdSelected)))
                            end
                        })

                        RageUI.Checkbox(labelFreeze, nil, freezecheck, {}, {
                            onChecked = function()
                                FreezeEntityPosition(IdSelected, true)
                                TGSE("YazhuAdmin:admin:freezelejoueur", IdSelected, true)
                                ESX.ShowNotification("<C>Joueur: ~o~"..GetPlayerName(GetPlayerFromServerId(IdSelected)).. "\n~s~Actions: ~b~Freeze~s~")
                                labelFreeze = "→ ~r~UnFreeze le joueur"
                            end,
                            onUnChecked = function()
                                FreezeEntityPosition(IdSelected, false)
                                TGSE("YazhuAdmin:admin:freezelejoueur", IdSelected, false)
                                ESX.ShowNotification("<C>Joueur: ~o~" ..GetPlayerName(GetPlayerFromServerId(IdSelected)).. "\n~s~Actions: ~b~UnFreeze~s~") 
                                labelFreeze = "→ Freeze le joueur"
                            end,
                            onSelected = function(Index)
                                freezecheck = Index
                            end
                        })

                        RageUI.Checkbox("→ Spectate le joueur", nil, spectatecheck, {}, {
                            onChecked = function()
                                if IdSelected == GetPlayerServerId(PlayerId()) then
                                    return ESX.ShowNotification("<C>~r~Vous ne pouvez pas vous regardez")
                                else
                                    local playerId = GetPlayerFromServerId(IdSelected)
                                    SpectatePlayer(GetPlayerPed(playerId), playerId)
                                    ESX.ShowNotification("Vous regardez "..GetPlayerName(GetPlayerFromServerId(IdSelected)))
                                end
                            end,
                            onUnChecked = function()
                                local targetPed = PlayerPedId()
                                local targetx,targety,targetz = table.unpack(GetEntityCoords(targetPed, false))
                                RequestCollisionAtCoord(targetx,targety,targetz)
                                NetworkSetInSpectatorMode(false, targetPed)
                            end,
                            onSelected = function(Index)
                                spectatecheck = Index
                            end
                        })
                        RageUI.Separator("↓ ~b~Option(s) avancé ~s~↓")
                        RageUI.Button(colors[actualColor].."→~s~ Information supplémentaire ", nil , {RightLabel = "→→"}, true , {
                            onSelected = function ()
                                GetAllInformationsPlayers()
                            end
                        }, SupplInfoAdmin)

                        if group == "admin" or "superadmin" then
                            RageUI.Button("→ Warn :  "..colors[actualColor]..""..tostring(GetPlayerName(GetPlayerFromServerId(IdSelected))), nil, {RightLabel = "→→"}, true , {
                                onSelected = function()
                                    local reason = KeyboardInput('Warn', ('Raison du Warn'), '', 100)
                                    if reason ~= nil and reason ~= "" then
                                        ESX.ShowNotification("<C>~y~Envoie du warn en cours...")
                                        TGSE("adminmenu:warn", IdSelected, reason)
                                    end
                                end
                            },warnmenu);
                        else
                            RageUI.Button("Warn ", nil, {RightLabel = "→→"}, false, {})
                        end

                        if group == "admin" or "mod" or "superadmin" then
                        RageUI.Button("→ Kick", nil , {RightLabel = "→→"}, true , {
                            onSelected = function ()
                                local mess = KeyboardInput('Raison du kick', ('Raison du kick'), '', 100)
                                if mess ~= nil then
                                    mess = tostring(mess)
                                    if type(mess) == 'string' then
                                        TGSE("YazhuAdmin:kick", IdSelected, mess)
                                    end
                                end
                            end
                        })
                        else 
                            RageUI.Button("→ Kick", nil , {RightLabel = ""}, false , {})
                        end

                        if group == "admin" or "superadmin" then
                            RageUI.Button("→ Ban", nil , {RightLabel = "→→"}, true , {
                                onSelected = function ()
                                    local banmessage = KeyboardInput("Raison du bannissement", "Raison", "", 75)
                                    TGSE(Config.TriggerBanPlayer, IdSelected, banmessage)
                                end
                            })
                            else 
                                RageUI.Button("→ Ban", nil , {RightLabel = ""}, false , {})
                            end

                            if group == "admin" or "superadmin" then
                                RageUI.Button("→ Clear son inventaire ", nil, {RightLabel = "→→"}, not time, {
                                    onSelected = function()
                                        time = true
                                        ExecuteCommand("clearinventory "..IdSelected)
                                        Citizen.SetTimeout(6000, function() time = false end)
                                    end
                                })
                            else
                                RageUI.Button("Clear son inventaire ", nil, {RightLabel = "→→"}, false, {})
                            end

                            if group == "admin" or "superadmin" then
                                RageUI.Button("→ Clear ses arme(s) ", nil, {RightLabel = "→→"}, not time1, {
                                    onSelected = function()
                                        time1 = true
                                        ExecuteCommand("clearloadout "..IdSelected)
                                        Citizen.SetTimeout(6000, function() time1 = false end)
                                    end
                                })
                            else
                                RageUI.Button("Clear ses arme(s) ", nil, {RightLabel = "→→"}, false, {})
                            end

                            if group == "admin" or "superadmin" then
                               
                                RageUI.Button("→ Rembourser un item", false, {RightLabel = "→→"}, true, {
                                    onSelected = function()
                                    end
                                }, GiveItemId)
                            else
                                RageUI.Button("Rembourser un item ", nil, {RightLabel = "→→"}, false, {})
                            end
                            if group == "admin" or "superadmin" then
                            RageUI.Button("→ Changer le job", nil, {RightLabel = "→→"}, true, {
                                onSelected = function()
                                    GetJobs()
                                end
                            }, JobsSetjobBystaff)
                        else
                            RageUI.Button("Changer le job ", nil, {RightLabel = "→→"}, false, {})
                        end
                    end)

                    RageUI.IsVisible(ReportMenuForstaff, function()

                        RageUI.Separator("Il y actuellement ~r~"..colors[actualColor] ..#reportlist.. "~s~ report")
                        if #reportlist >= 1 then
                            for k,v in pairs(reportlist) do
                                RageUI.Button("~o~#~s~"..k.." [~g~"..v.nom.."~s~] (~b~"..v.id.."~s~)", nil, {RightLabel = "→→"},true , {
                                    onSelected = function()
                                        nom = v.nom numeroreport = k id = v.id raison = v.args
                                    end
                                    
                                }, inforeport);
                            end
                        else
                            RageUI.Separator("")RageUI.Separator(colors[actualColor].."Aucun Report")RageUI.Separator("")
                        end
                    end)

                RageUI.IsVisible(inforeport, function()
                     RageUI.Separator("Report : #~b~"..tostring(numeroreport))
                     RageUI.Separator("Nom : ~g~"..tostring(nom))
                     RageUI.Button("Raison", "Raison :~b~ "..tostring(raison), {RightLabel = "→→"}, false, {
                        onSelected = function()
                        end
                    })
                
                if not reportselect then 
                     RageUI.Button("→ ~g~Prendre en charge", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            reportselect = true
                            ESX.ShowNotification("<C>Vous avez pris le report n°~r~"..#reportlist.."~s~ de ~r~"..tostring(nom))
                        end
                    })
                else 
                    RageUI.Button("Prendre en charge", nil, {RightLabel = "→→"}, false, {})
                    RageUI.Button("~b~→~s~ Se téléporter sur lui", nil, {RightLabel = "→→"}, reportselect,{
                        onSelected = function()
                            SetEntityCoords(PlayerPedId(), GetEntityCoords(GetPlayerPed(GetPlayerFromServerId(IdSelected))))
                            ESX.ShowNotification("<C>Téléportation sur ~o~".. GetPlayerName(GetPlayerFromServerId(IdSelected)).. "~s~ effectué")
                        end
                    })

                    RageUI.Button("~b~→~s~ Téléporter sur moi", nil, {RightLabel = "→→"}, reportselect, {
                        onSelected = function()
                            local plyPedCoords = GetEntityCoords(PlayerPedId())
                            TGSE('YazhuAdmin:bringplayer', IdSelected, plyPedCoords)
                        end
                    })

                    RageUI.Button("~b~→~s~ Envoyer un message", nil, {RightLabel = "→→"}, reportselect,{
                        onSelected = function()
                            local raison = KeyboardInput('Message', ('écrivez votre message'), '', 1000)
                            if raison ~= nil then
                                raison = tostring(raison)
                                if type(raison) == 'string' then
                                    TGSE("YazhuAdmin:Message", IdSelected, raison)                                
                                end
                            end
                            ESX.ShowNotification("Vous venez d'envoyer le message à ~r~" .. GetPlayerName(GetPlayerFromServerId(IdSelected)))
                        end
                    })

                    RageUI.List("→ TP le joueur" ..colors[actualColor].."(Yazhu)", {"Parking Central", "Hopital", "Commissariat"}, MenuPersoList.List1, nil, {}, true, {
                        onListChange = function(i, Item)
                            MenuPersoList.List1 = i;
                        end,
                        onSelected = function (i)
                        if i == 1 then
                            local NamePlayer = GetPlayerName(PlayerId())
                            local NameTarget = IdSelected
                            for k,v in pairs(Config.TeleportList.Pos.Pc) do
                                local admin_coords = v.pospc
                                local joueurss = IdSelected
                                TGSE("YazhuAdmin:bring", admin_coords, joueurss)
                            end
                            elseif i == 2 then
                                local NamePlayer = GetPlayerName(PlayerId())
                                local NameTarget = IdSelected
                                local PlayerId = GetPlayerServerId(PlayerId())
                                for k,v in pairs(Config.TeleportList.Pos.Fourriere) do
                                    local admin_coords = v.posf
                                    local joueurss = IdSelected
                                    TGSE("YazhuAdmin:bring", admin_coords, joueurss)
                                end
                            end
                        end,
                    })

                    RageUI.Button("~r~→~s~ Clôturer le report ~r~ #"..#reportlist, nil, {RightLabel = "→→"}, reportselect, {
                        onSelected = function()
                            TGSE('YazhuAdmin:CloseReport', nom, raison)
                            TGSE("YazhuAdmin:message", id, "~o~Staff~s~\nVotre report à été fermé !")
                            RageUI.GoBack()
                            ESX.ShowNotification("<C>Tu as fermé le report #~b~"..#reportlist.. "~s~ de ~r~" ..tostring(nom))
                        end
                    })
                end
            end)
                    RageUI.IsVisible(SupplInfoAdmin, function()
                        for k,v in pairs(invName) do
                            RageUI.Separator("Identité "..colors[actualColor].."→ ~g~"..v.label)
                        end
                        for k,v in pairs(invMoney) do
                            RageUI.Separator("Argent (~g~Cash~s~) "..colors[actualColor].."→ ~s~"..v.cash)
                            RageUI.Separator("Argent (~r~Sale~s~) "..colors[actualColor].."→ ~s~"..v.dirty)
                            RageUI.Separator("Argent (~b~Banque~s~) "..colors[actualColor].."→ ~s~"..v.bank)
                        end
                        for k,v in pairs(invJob) do
                            RageUI.Separator("Métier "..colors[actualColor].."→ ~s~"..v.job)
                            RageUI.Separator("Gang/Organistaion "..colors[actualColor].."→ ~s~"..v.job2)
                        end
                        RageUI.Separator("↓ ~r~Item(s)~s~ ↓")

                        if #invItems >= 1 then
                        for k,v in pairs(invItems) do
                           
                                RageUI.Button(colors[actualColor].."→ ~s~"..v.label  , nil, {RightLabel = "→→"}, true, {
                                    onSelected = function ()
                                        local amount = KeyboardInput("Item_Amount", "Quantité à supprimé", "", 8)
                                        if tonumber(amount) <= tonumber(v.count) then
                                            TGSE("YazhuAdmin:RetryItems", IdSelected, v.item , tonumber(amount))
                                            ESX.ShowNotification("Vous avez retiré x"..amount)
                                        else
                                            ESX.ShowNotification("~r~Quantité invalide")
                                        end
                                    end
                                })
                            end
                        else 
                            RageUI.Separator(colors[actualColor].."Aucun Item(s) sur le joueur")
                        end
                
                        RageUI.Separator("↓ ~o~Arme(s)~s~ ↓")
                        if #invWeapon >= 1 then
                        for k,v in pairs(invWeapon) do
                            RageUI.Button(colors[actualColor].."→ ~s~"..v.label  , nil, {RightLabel = "→→"}, true, {})
                        end
                    else
                        RageUI.Separator(colors[actualColor].."Aucune arme(s) sur le joueur")
                    end
                end)
                    RageUI.IsVisible(GiveItemId, function()
                        RageUI.Separator(colors[actualColor].."(Yazhu)")
                        RageUI.Separator("↓ Liste des items dans la BDD ↓")
                        RageUI.Button("               [-] Rechercher un ~r~item~s~",nil,{},true, {
                            onSelected = function()
                                ItemFiltre = KeyboardInput('Entrez un ~r~ID~s~ (ENTRER pour tout remettre)', (''), '', 100)
                                    if ItemFiltre == "" then
                                        ESX.ShowNotification("<C>~r~Valeur non précise ou incorrect")
                                    else
                                    if ItemFiltre == nil then
                                        ESX.ShowNotification("<C>~r~Valeur non précise ou manquante")
                                    else
                                        ESX.ShowNotification("<C>~r~Administration~s~\nVous avez chercher la lettre ~g~"..ItemFiltre)
                                    end
                                end
                            end
                        })

                        for k,v in pairs(items) do
                            if ItemFiltre == nil or string.find(v.label,ItemFiltre) then
                            RageUI.Button(colors[actualColor].."→~s~ "..v.label, "Appuyez pour donner cet item", { RightLabel = "→→" }, true, {
                                onSelected = function()
                                    local qty = KeyboardInput('Quantité', (''), '', 100)
                                    TGSE("YazhuAdmin:RemboursementItem", qty.onSelected, v.name,IdSelected, qty)
                                end
                            })
                            end
                        end
                    end)
                end
            end)
        end
    end
end

RegisterNetEvent("YazhuAdmin:freezeplayer")
AddEventHandler("YazhuAdmin:freezeplayer", function(state)
    FreezeEntityPosition(PlayerPedId(), state)
end)

RegisterNetEvent("YazhuAdmin:teleport_player")
AddEventHandler("YazhuAdmin:teleport_player", function (coords_vector3)
    local Source = source
    last_pos = fixVector(GetEntityCoords(GetPlayerPed(-1)))
    if Source ~= "" then
        if tonumber(Source) > 64 then
            SetEntityCoords(GetPlayerPed(-1), coords_vector3)
            FreezeEntityPosition(GetPlayerPed(-1), true)
            Citizen.Wait(1000)
            FreezeEntityPosition(GetPlayerPed(-1), false)
        end
    end
end)

RegisterNetEvent("YazhuAdmin:getItems")
AddEventHandler("YazhuAdmin:getItems", function(table)
    items = table
end)

RegisterNetEvent('YazhuAdmin:bringplayer')
AddEventHandler('YazhuAdmin:bringplayer', function(plyPedCoords)
    plyPed = PlayerPedId()
	SetEntityCoords(plyPed, plyPedCoords)
end)

RegisterNetEvent("YazhuAdmin:envoyer")
AddEventHandler("YazhuAdmin:envoyer", function(reason)
    PlaySoundFrontend(-1, "CHARACTER_SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1)
    ESX.ShowAdvancedNotification('<C>Administration', '<C>~r~Message Staff',  "<C>"..reason, 'CHAR_DEFAULT', 1)
end)

RegisterCommandKey("Noclip", "Administration | Noclip", "F2", function()
    ESX.TriggerServerCallback('YazhuAdmin:getGroupOfPlayer', function(group)
        playergroup = group
        if playergroup == 'superadmin' or playergroup == 'admin' or playergroup == 'mod' then
        if staffservice then 
            if noclip == false then
                noclip = true
                invisible = true
                labelnoclip = "~r~Désactiver Noclip~s~"
                initializeNoclip()
                initializeInvis()
                FreezeEntityPosition(GetPlayerPed(-1), true)
            elseif noclip then
                noclip = false
                invisible = false
                labelnoclip = "→~s~ Activer Noclip"
                FreezeEntityPosition(GetPlayerPed(-1), false)
                SetEntityCollision(GetPlayerPed(-1), 1, 1)
                SetEntityVisible(GetPlayerPed(-1), 1, 0)
                NetworkSetEntityInvisibleToNetwork(GetPlayerPed(-1), 0)
            end
        end
        else
            ESX.ShowAdvancedNotification('<C>Administration', '<C>Système', '<C>~r~Permissions insufisantes.', 'CHAR_DEFAULT', 1)
        end
    end)
end)

Keys.Register(Config.ToucheMenu, Config.OpenMenuChat, 'Ouverture du Menu', function()
    ESX.TriggerServerCallback('YazhuAdmin:getGroupOfPlayer', function(group)
        playergroup = group
        if playergroup == 'superadmin' or playergroup == 'admin' or playergroup == 'mod' then
            OpenAdminMenu()
        else
            ESX.ShowAdvancedNotification('<C>Administration', '<C>Système', '<C>~r~Permissions insufisantes.', 'CHAR_DEFAULT', 1)
        end
    end)
end)


function Keyboardput(TextEntry, ExampleText, MaxStringLength)

    AddTextEntry('FMMC_KEY_TIP1', TextEntry .. ':')
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLength)
    blockinput = true

    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
        Citizen.Wait(0)
    end

    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Citizen.Wait(500)
        blockinput = false
        return result
    else
        Citizen.Wait(500)
        blockinput = false
        return nil
    end
end